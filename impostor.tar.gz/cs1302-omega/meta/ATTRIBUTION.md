* Knife
    - "resources/knife.png"
    - Author: Lunar the Espeon. 12/14/2020
    - URL: https://www.tinkercad.com/things/g6EDV9BiKmb-impostor-knife-among-us
    - © 2022 Autodesk, Inc, All Rights Reserved.
* Impostor
    - "resources/mole.png"
    - Author: Apptopia. 11/2020
    - URL: https://play-lh.googleusercontent.com/-YfNuZ1afQNRQr8TVhmvkMbnH9lRpap4GukuGjqAEIsfthRJVT75hF1hNUkgOlbgu-oi
    - (C) Apptopia 2022
* Vent
    - "resources/hole.png"
    - Author: Shamrock_2225. 12/28/2022
    - URl: http://s3.amazonaws.com/gt7sp-prod/decal/88/48/63/8511883637456634888_1.png
    - © 2022 Sony Interactive Entertainment Inc. Developed by Polyphony Digital Inc. Manufacturers, cars, names, brands and associated imagery featured in
        this game in some cases include trademarks and/or copyrighted materials of their respective owners. All rights reserved. Any depiction or
        recreation of real world locations, entities, businesses, or organizations is not intended to be or imply any sponsorship or endorsement of this
        game by such party or parties. "Gran Turismo" logos are registered trademarks or trademarks of Sony Interactive Entertainment Inc.
* Space
    - "resources/space.png"
    - Author: Tina Hilding. 3/10/2022
    - URL: https://s3.wp.wsu.edu/uploads/sites/2797/2022/03/space.jpg
    - © Washington State University 2021
* Grass
    - "resources/grass.png"
    - Author: Tony Bort
    - URL: https://i.pinimg.com/originals/b9/4c/c9/b94cc9753e674518e4bb3ef1bc3fd9f3.jpg
    - Pinterest
