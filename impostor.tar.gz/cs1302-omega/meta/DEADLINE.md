Part 1:
    This game is similar to Whack A Mole. Just a little tweak to the game, instead of moles, I use the Among Us character.
    Players have 60 seconds to whack as many impostors as they can to earn points. Each impostor worths 1 point.
Part 2:
    I love during this project because I have so much freedom and I learned a lot from searching how to do certain tasks on the internet.
Part 3:
    If I could start over, I would start working on this much earlier to make the game even better.